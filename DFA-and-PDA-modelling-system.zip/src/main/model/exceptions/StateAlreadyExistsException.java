package main.model.exceptions;

/**
 * StateAlreadyExistsException
 */
public class StateAlreadyExistsException extends Exception{


    public StateAlreadyExistsException() {
        super("State already exists");
    }

    

    
}