# DFA-and-PDA-modelling-system
This is a repository for my Computer Science Bsc thesis. My thesis is a program for modelling deterministic finite automatons (DFA) and pushdown automatons (PDA)
